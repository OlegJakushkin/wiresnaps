import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
export default defineConfig({base:'./',plugins:[react()],build:{target:'es2022',chunkSizeWarningLimit:1800},worker:{format:'es'},test:{include:['tests/**/*.test.ts'],environment:'node'}} as import('vite').UserConfig);
